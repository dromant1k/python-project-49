
### Hexlet tests and linter status:
[![Actions Status](https://github.com/dromant1k/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/dromant1k/python-project-49/actions)
https://asciinema.org/a/1dsUIAqQz0I2XcCMhg4Rq4Pf6 - asciinema brain_even
https://asciinema.org/a/sjfeFE2m022KBXwGNJDpRjjf1 - asciinema brain_calc
https://asciinema.org/a/1wjQyQrLsNVOZ7twEkaRQenms - asciinema brain_gcd
