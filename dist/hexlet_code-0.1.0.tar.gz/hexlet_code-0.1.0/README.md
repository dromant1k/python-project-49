### Hexlet tests and linter status:
[![Actions Status](https://github.com/dromant1k/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/dromant1k/python-project-49/actions)
https://asciinema.org/a/1dsUIAqQz0I2XcCMhg4Rq4Pf6 - asciinema brain_even

